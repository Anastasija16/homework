import java.util.Scanner;

public class Exercise2 {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int theProductPrice = scn.nextInt();
        int theMoneyFrom = scn.nextInt();
        double returnMoneyOfE = theProductPrice >= theMoneyFrom ? (theProductPrice - theMoneyFrom): theMoneyFrom;
        System.out.println(returnMoneyOfE);

    }
}
/*
 Пользователь-продавец вводит суммарную стоимость покупок и сумму денег,
  которую дал покупатель. Выведите сумму сдачи в виде “X рублей и Y копеек”.
 */