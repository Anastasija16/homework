import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        int longm = 500;
        int longkm = 01;
        int longmil = 062;
        int longf = 328;
        int longa = 1;
        System.out.println(longm*longkm);
        System.out.println(longm*longmil);
        System.out.println(longm*longf);
        System.out.println(longm*longa);


    }

        /*
         Дана длина в метрах. Напишите программу, которая переводит
         указанное значение в км,
         мили, футы и аршины.
         Выведите начальное и конвертированные значения на экран.
         */

}