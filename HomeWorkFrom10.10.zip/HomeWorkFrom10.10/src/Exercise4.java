import java.util.Scanner;

public class Exercise4 {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int number = 22;
        System.out.println(number / 2);


    }
}
    /*
    Пользователь вводит целое число. Напишите программу,
     которая делит это число на 2 и выводит результат.
     Остаток деления можно отбросить. Операторы деления /,
     умножения * и остатка от деления % применять нельзя.
    */