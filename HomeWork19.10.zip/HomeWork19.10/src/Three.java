import java.time.DayOfWeek;
import java.util.Scanner;

public class Three {
    public static void main(String[] args) {
        for (String s:args) {
            System.out.println(s);
        }
        for (DayOfWeek l : DayOfWeek.values()) {
            System.out.println(l);
        }

    }
}
/*
Используйте foreach.
Дан Enum дней недели. Пользователь вводит имя текущего дня в консоль.
Программа должна вывести все дни недели, кроме данного.
 */