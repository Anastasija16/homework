import java.util.Scanner;

public class Two {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("enter your number");
        int sum = 10;
        while (true) {
            String st = scn.nextLine();
            if ("stop".equalsIgnoreCase(st)) break;
            boolean isNumber = true;
            for (int i = 0; i < st.length(); i++) {
                char current = st.charAt(i);
                isNumber = isNumber && Character.isDigit(current);
            }
            if (!isNumber) continue;
            {
                System.out.println("weiter");
                continue;
            }
        }
        Scanner scn = new Scanner(System.in);
        String userStr = "";
        while (!"quit".equalsIgnoreCase(userStr)) {
            System.out.println("Введите quit для выхода");
            userStr = scn.nextLine();
        }
    }
}
/*
Используйте for для вычисления суммы.
Используйте do-while для организации повторения программы.

Необходимо суммировать все нечётные целые числа в диапазоне,
 введённом пользователем. Программу повторять, пока пользователь не введёт «quit».
 */