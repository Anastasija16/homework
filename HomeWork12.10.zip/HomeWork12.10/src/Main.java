import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Random rn = new Random();
        int m = rn.nextInt(0, 100);
        int n = rn.nextInt(0, 100);
        System.out.println("первый номер"+ m);
        System.out.println("первый номер"+ n);

        System.out.printf(Math.abs(10-m)>Math.abs(10-n)?"Число %d ближе к 10": "Число %d ближе к 10", m,n);
        if (Math.abs(10-m)>Math.abs(10-n)) {
            System.out.println(" Число " + n + " ближе к 10 ");
        } else {
            System.out.println(" Число " + m + " ближе к 10 ");
        }
        }


    }
/*
Создать программу, выводящую на экран ближайшее к 10 из двух чисел,
 записанных в переменные m и n.
Числа могут быть, как целочисленные, так и дробные.

Например :
ввод : m=7, n=11
вывод: Число 11 ближе к 10.
 */