import java.util.Random;
import java.util.Scanner;

public class Exercise2 {
    public static void main(String[] args) {
      Random rnd1 = new Random();
      Random rnd2 = new Random();
      int nr1 = rnd1.nextInt(1,100);
      int nr2 = rnd2.nextInt(1,100);
        System.out.println(nr1 + " * " + nr2);
        System.out.println("Whrite result");
        Scanner scr = new Scanner(System.in);
        int summe = scr.nextInt();
        if (nr1 * nr2 == summe) {
            System.out.println(summe);
        }
    }
}

/*
Необходимо написать программу, которая проверяет пользователя на знание таблицы умножения.
 Программа генерирует два целых однозначных числа. Программа задаёт вопрос: результат умножения
  первого числа на второе?  Пользователь должен ввести ответ и увидеть на экране правильно он ответил или нет.
 Если пользователь ответил неправильно, то программа должна показать правильный ответ.
 */
