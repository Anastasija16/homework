import java.util.Scanner;

public class Exercise3 {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("take Elvis Birthday");
        int elvisBirthday = scn.nextInt();
        if (elvisBirthday < 1935){
            System.out.println("he has not been born yet");
        }
        if (elvisBirthday > 1977){
            System.out.println("elvis is dead");
        }
        if (elvisBirthday <= 1977){
            System.out.println("elvis alive");
        }
    }
}
/*
Элвис Пресли жил с 1935 по 1977 год. Используя тернарные операторы, напишите программу,
в которой пользователь вводит год. Если указанный год меньше 1935, то вывести «Элвис ещё не родился».
 Если указанный пользователем год с 1935 по 1977 включительно, то вывести «Элвис жив!».
Если введённый пользователем год больше 1977, то вывести «Элвис навсегда в наших сердцах!»
 */
