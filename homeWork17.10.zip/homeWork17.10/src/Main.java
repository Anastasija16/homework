import java.util.Scanner;

import static godovhina.Svadba.;

public class Main {
    public static void main(String[] args) {
        System.out.println("enter year");
        Scanner scn = new Scanner(System.in);
        int Svadba = scn.nextInt();
        String godovhina = switch (Svadba) {
            case 1 ->  СИТЦЕВАЯ;
            case 2 ->  БУМАЖНАЯ;
            case 3 ->  КОЖАНАЯ;
            case 5 ->  ЛЬНЯНАЯ;
            case 6 ->  ДЕРЕВЯННАЯ;
            case 7 ->  ЧУГУННАЯ;
            case 8 ->  МЕДНАЯ;
            case 9 ->  ЖЕСТЯНАЯ;
            case 10 -> ФАЯСНОВАЯ;
            case 11 -> ОЛОВЯННАЯ;
            case 12 -> СТАЛЬНАЯ;
            case 13 -> НИКЕЛЕВАЯ;
            case 14 -> КРУЖЕВНАЯ;
            case 15 -> АГАТОВАЯ;
            case 16 -> ХРУСТАЛЬНАЯ;
            case 17 -> ТОПАЗОВАЯ;
            case 18 -> РОЗОВАЯ;
            case 19 -> БИРЮЗОВАЯ;
            case 20 -> ГРАНАТОВАЯ;
            case 21 -> ФАРФОРАВАЯ;
            case 22 -> ОПАЛОВАЯ;
            case 23 -> БРОНЗОВАЯ;
            case 24 -> БЕРИЛЛОВАЯ;
            case 25 -> АТЛАСНАЯ;
            case 26 -> СЕРЕБРЯНАЯ;
            case 27 -> НЕРФРИТОВАЯ;
            case 28 -> КРАСНОЕ;
            case 29 -> НИКЕЛЕВАЯ;
            case 30 -> БАРХАТНАЯ;
            case 31 -> ЖЕМЧУЖНАЯ;
            case 32 -> СОЛНЕЧНАЯ;
            case 33 -> МЕДНАЯ;
            case 34 -> КАМЕННАЯ;
            case 35 -> ЯНТАРНАЯ;
            case 36 -> КОРАЛЛОВАЯ;
            case 37 -> КОСТЯНОЙ;
            case 38 -> МУСЛИНОВАЯ;
            case 39 -> РТУТНАЯ;
            case 40 -> КРЕПОВАЯ;
            case 41 -> РУБИНОВАЯ;
            case 42 -> ЖЕЛЕЗНАЯ;
            case 43 -> ПЕРЛАМУТРИВОЯ;
            case 44 -> ФЛАНЕЛЕВАЯ;
            case 45 -> ТОПАЗОВАЯ;
            case 46 -> САПФИРОВАЯ;
            case 47 -> ЛАВАНДОВАЯ;
            case 48 -> КАШЕМИРОВАЯ;
            case 49 -> АМЕТИСТОВАЯ;
            case 50 -> КЕДРИВОЯ;
            case 51 -> ЗОЛОТАЯ;
            case 52 -> ИВОВАЯ;
            case 53 -> ТОПАЗОВАЯ;
            case 55 -> УРАНОВАЯ;
            case 56 -> ИЗУМРУДНАЯ;
            case 57 -> ИВОВАЯ;
            case 58 -> АЛЮМИНИЕВАЯ;
            case 59 -> ЗЕЛЕНАЯ;
            case 60 -> СВЕТЛАЯ;
            case 61 -> БРИЛЛИАНТОВАЯ;
            case 62 -> БОГАТАЯ;
            case 63 -> АКВАМАРИНОВАЯ;
            case 64 -> РТУТНАЯ;
            case 65 -> ВЕСЕЛАЯ;
            case 66 -> ЖЕЛЕЗНАЯ;
            case 67 -> НЕОНОВАЯ;
            case 68 -> ВОЛЩЕБНАЯ;
            case 69 -> РОМАШКОВАЯ;
            case 70 -> АТЛАСНАЯ;
            case 75 -> БЛАГОДАТНАЯ;
            case 80 -> КОРОННАЯ;
            case 85 -> ДУБОВАЯ;
            case 90 -> ВИННАЯ;
            case 95 -> ГРАНИТНАЯ;
            case 100 -> КРАСНАЯ;
            default -> "Unknown";
        };
        System.out.println(godovhina);

    }
}
/*
Пользователь вводит, сколько лет он состоит в браке.
Программа должна вывести, какая годовщина свадьбы будет у пользователя следующей
(бумажная, ситцевая, чугунная, серебряная и.д.). Не обязательно указывать все годовщины,
достаточно 10-15. Узнать про
годовщины можно, например, здесь https://instalook.ru/blog/nazvaniya-vseh-godovschin-svadeb-do-100-let
 */