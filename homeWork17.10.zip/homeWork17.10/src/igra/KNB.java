package igra;

public enum KNB {
    КАМЕНЬ,
    НОЖНИЦЫ,
    БУМАГА;

}
