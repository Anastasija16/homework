import igra.KNB;

import java.util.Random;
import java.util.Scanner;

public class задание2 {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        Random rnd = new Random();
        System.out.println("enter one of the option");
        String choices = scn.nextLine();
        KNB noDefault = KNB.valueOf(choices.toUpperCase());
        KNB userChoices = switch (noDefault) {
            case  КАМЕНЬ -> KNB.КАМЕНЬ;
            case  НОЖНИЦЫ -> KNB.НОЖНИЦЫ;
            case  БУМАГА -> KNB.БУМАГА;
        };
        System.out.println("your choices" + userChoices );
        System.out.println("now pc");
        int program = rnd.nextInt(KNB.values().length);
        KNB progChoice = KNB.values()[program];
        System.out.println("pc choice" + progChoice);
        if (userChoices.equals(progChoice)){
            System.out.println("draw");
        } else if (userChoices == KNB.НОЖНИЦЫ && progChoice == KNB.БУМАГА || userChoices == KNB.КАМЕНЬ && progChoice == KNB.НОЖНИЦЫ || userChoices == KNB.БУМАГА && progChoice == KNB.КАМЕНЬ) {
            System.out.println("you won");
        }
    }

}
/*
Напишите консольную игру «Камень, ножницы, бумага». Пользователь вводит свой выбор (в виде строки или числа).
 Программа случайным образом делает свой выбор и выводит на экран. Далее программа показывает,
 кто победитель – пользователь или программа.
 */