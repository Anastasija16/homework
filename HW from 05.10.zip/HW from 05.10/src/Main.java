import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("the price of the product");
        int thePrice = scn.nextInt();
        int discount = 30;
        int limit = 100;
        double PriceWithDiscount = thePrice >= limit ? (thePrice * discount / 100.0) : thePrice;
        System.out.println(PriceWithDiscount);
    }
        /*Расчет стоимости товара с учетом скидки: Создайте программу для
         расчета стоимости товара с учетом скидки.
         Если сумма покупки больше определенного значения, примените скидку.
         */

}