import java.util.Scanner;

public class Exercise2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Уважаемый ");
        String name = input.nextLine();
        System.out.println(",В свои ");
        int age = input.nextInt();
        System.out.println("лет Вы для нас дороги,как");
        double kg = input.nextDouble();
        System.out.println("килограмм золота");
        System.out.println("Уважаемый " + name + ",В свои " + age + " лет Вы для нас дороги,как " + kg + " килограмм золота");
    }

    /*
    Напишите программу, которая принимает от пользователя его имя, возраст (полных лет) и вес.
     Когда все данные введены, программа должна выдать сообщение: «Уважаемый, [Имя]! В свои [Возраст] лет Вы для нас дороги,
     как [Вес] килограмм золота.». В сообщении [Имя], [Возраст] и [Вес] должны принять введённые значения
     */
}
