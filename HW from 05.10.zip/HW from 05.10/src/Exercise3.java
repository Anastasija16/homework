import java.util.Random;
import java.util.Scanner;

public class Exercise3 {
    public static void main(String[] args){
        Random rnd = new Random();
        int i = rnd.nextInt(60);
        System.out.println(i);
        i = i+1;
        System.out.println(i);
        i += 1;
        System.out.println(i);
        i ++;
        System.out.println(i);

        /*
        Напишите программу, которая получает от пользователя два целых числа и затем вычисляет сумму (сложение),
        разницу (вычитание), произведение (умножение) и частное (деление) введённых чисел.
         Результат вычислений выведите в консоль.
         */
}
}
